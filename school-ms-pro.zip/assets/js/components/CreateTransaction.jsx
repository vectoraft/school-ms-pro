import React from 'react';
const CreateTransaction = () => (
  <div>
    <h2 className="text-xl font-bold mb-4">Create Transaction</h2>
    {/* Transaction form here */}
    <div className="bg-white p-6 rounded shadow">Transaction form...</div>
  </div>
);
export default CreateTransaction;
