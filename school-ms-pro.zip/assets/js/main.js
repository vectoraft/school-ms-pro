// Main React entry for SPA dashboard
import React, { useEffect } from 'react';
import { createRoot } from 'react-dom/client';
import App from './components/App.jsx';
import '../css/main.css';
import '../css/custom-theme.css';
import '../css/print.css';
import tippy from 'tippy.js';
import 'tippy.js/dist/tippy.css';

const container = document.getElementById('school-ms-pro-root');
if (container) {
  createRoot(container).render(<App />);
}

useEffect(() => {
  tippy('[data-tip]', { placement: 'top', theme: 'light-border' });
}, []);
