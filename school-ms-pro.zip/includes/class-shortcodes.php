<?php
// Handles all plugin shortcodes and Elementor integration
class School_MS_Pro_Shortcodes {
    public static function register_shortcodes() {
        // Dashboard shortcode
        add_shortcode('schoolms_dashboard', function($atts) {
            ob_start();
            echo '<div id="school-ms-pro-root"></div>';
            echo '<script src="/wp-content/plugins/school-ms-pro/assets/js/main.js"></script>';
            return ob_get_clean();
        });
        // Login shortcode
        add_shortcode('schoolms_login', function($atts) {
            ob_start();
            include plugin_dir_path(__FILE__) . '../templates/login.php';
            return ob_get_clean();
        });
    }
    public static function output_shortcode_guide() {
        $guide = "School MS Pro Shortcodes & Elementor Guide\n\n";
        $guide .= "[schoolms_dashboard] — Main dashboard (React)\n";
        $guide .= "[schoolms_login] — Login form\n";
        $guide .= "[schoolms_students] — Students table\n";
        $guide .= "[schoolms_teachers] — Teachers table\n";
        $guide .= "[schoolms_parents] — Parents table\n";
        $guide .= "[schoolms_library] — Library/books\n";
        $guide .= "[schoolms_fees] — Fees/payments\n";
        $guide .= "[schoolms_notifications] — Notifications\n";
        $guide .= "[schoolms_messages] — Messaging\n";
        $guide .= "[schoolms_analytics] — Analytics\n";
        $guide .= "[schoolms_audit] — Audit log\n";
        $guide .= "[schoolms_roles] — Roles/permissions\n";
        $guide .= "\nUsage: Paste any shortcode into a page, post, or widget. For Elementor, use the Shortcode widget and paste the code.\n";
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="schoolms-shortcodes-guide.txt"');
        echo $guide;
        exit;
    }
    public static function register_elementor_widgets() {
        // Only register if Elementor is active
        if (!did_action('elementor/loaded')) return;
        add_action('elementor/widgets/widgets_registered', function($widgets_manager) {
            $widgets = [
                'schoolms_dashboard' => 'School MS Pro Dashboard',
                'schoolms_students' => 'Students Table',
                'schoolms_teachers' => 'Teachers Table',
                'schoolms_parents' => 'Parents Table',
                'schoolms_library' => 'Library/Books',
                'schoolms_fees' => 'Fees/Payments',
                'schoolms_notifications' => 'Notifications',
                'schoolms_messages' => 'Messaging',
                'schoolms_analytics' => 'Analytics',
                'schoolms_audit' => 'Audit Log',
                'schoolms_roles' => 'Roles/Permissions',
            ];
            foreach ($widgets as $shortcode => $title) {
                $widgets_manager->register(new class($shortcode, $title) extends \Elementor\Widget_Base {
                    private $shortcode;
                    private $title;
                    public function __construct($shortcode, $title) {
                        $this->shortcode = $shortcode;
                        $this->title = $title;
                        parent::__construct();
                    }
                    public function get_name() { return $this->shortcode; }
                    public function get_title() { return $this->title; }
                    public function get_icon() { return 'eicon-post-list'; }
                    public function get_categories() { return ['general']; }
                    protected function render() {
                        echo do_shortcode("[{$this->shortcode}]");
                    }
                });
            }
        });
    }
}
