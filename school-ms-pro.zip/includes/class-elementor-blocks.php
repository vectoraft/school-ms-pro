<?php
// Elementor widgets for all plugin features
class School_MS_Pro_Elementor_Blocks {
    public static function register_widgets() {
        // Register Elementor widgets for dashboards, analytics, etc.
    }
}
